﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Groupe23Lib.GeneratedCode
{
    class EyeXImpl : EyeTracker
    {

        void EyeTracker.detectClic(bool lClic, bool rClic)
        {
            throw new NotImplementedException();
        }

        void EyeTracker.detectPosition(uint xPos, uint yPos)
        {
            throw new NotImplementedException();
        }
    }
}
